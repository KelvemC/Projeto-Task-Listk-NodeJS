const bodyParser = require("body-parser");
const express = require("express");
const app = express();
const path = require("path");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));

//criando sistema para renderizar arquivo de forma automático
app.engine("html", require("ejs").renderFile); //setando a engine para renderização do tipo html, usando o ejs
app.set("view engine", "html");//setando a view engine para ser html
app.use("/public", express.static(path.join(__dirname, "public")));//dizendo onde fica o diretório estatático com arquivos, fotos, css, tudo que é estático
app.set("views", path.join(__dirname, "/views"));//dizendo onde está a página com as views

var tarefas = ["Arrumar o quarto", "Estudar", "Fazer compras"];

app.get("/", (req, res)=>{
    //O segundo parâmetro me permite interagir com minha view
    res.render("index", {tarefasList:tarefas});
});

app.get("/deletar/:id", (req, res)=>{
    tarefas = tarefas.filter((val, index)=>{
        if(index != req.params.id){
            return val;
        };
    });
    res.render("index", {tarefasList:tarefas});
});

app.post("/", (req, res)=>{
    tarefas.push(req.body.tarefa);
    res.render("index", {tarefasList:tarefas}); 
})

app.listen(8080, ()=>{
    console.log("Servidor iniciado!");
});